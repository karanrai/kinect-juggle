Installation Info:
http://code.google.com/p/kinect-juggle/wiki/InstallationInfo